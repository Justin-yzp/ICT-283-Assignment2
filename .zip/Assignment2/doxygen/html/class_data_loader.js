var class_data_loader =
[
    [ "DataLoader", "class_data_loader.html#a1e3bfa6d0116f0ecc8ec4596e35a09f0", null ],
    [ "LoadData", "class_data_loader.html#af44b7b6acfc673fdfa9ee5b3a8f0b1b5", null ],
    [ "data", "class_data_loader.html#a7c69ea242558c67f74e1ca4e3da61704", null ]
];