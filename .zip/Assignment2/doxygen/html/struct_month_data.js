var struct_month_data =
[
    [ "getSolarRadiation", "struct_month_data.html#a8cddbff431a32285852ccbfe61d39ca7", null ],
    [ "getTemperature", "struct_month_data.html#a94ea9d038653a89c6b02773ec26a9fd4", null ],
    [ "getWindSpeed", "struct_month_data.html#a4c1cb5463ee174a27a0d37f5e514335d", null ],
    [ "m_day", "struct_month_data.html#a95c619d9385e2e34aa27ee7c7c975777", null ],
    [ "m_month", "struct_month_data.html#a8e5b218cfafb3e708f73ab9e3e8dd020", null ],
    [ "m_solarRadiation", "struct_month_data.html#acc3adec90a933b32a20663edf5fc3dcd", null ],
    [ "m_temperature", "struct_month_data.html#aa01dbb948e94b0c0f8fc82d10a0960bd", null ],
    [ "m_windSpeed", "struct_month_data.html#a79340d4144f81483038adda57bc9f47e", null ],
    [ "m_year", "struct_month_data.html#ad8bc79c1c55c02ff30f6285a98afdb41", null ]
];