var class_weather_data =
[
    [ "WeatherData", "class_weather_data.html#a99d3a728ca282f6668cbcf37a21f1e2b", null ],
    [ "CalculateAverage", "class_weather_data.html#a70c734e710bb8b9ab85234cfe473e640", null ],
    [ "CalculateAverage", "class_weather_data.html#abc6293d649af3eddfc231c359d0b26fe", null ],
    [ "CalculateSPCC", "class_weather_data.html#a8ac06a32d094a84a563d01d779e074e0", null ],
    [ "CalculateStandardDeviation", "class_weather_data.html#a078589fe5dbbbdf691d79de21647b49f", null ],
    [ "CalculateTotal", "class_weather_data.html#aa152e19ce16c31e7c60e23355f85d4aa", null ],
    [ "DisplayDataForYear", "class_weather_data.html#abcf67600e3c77eabe42198aec3ae1547", null ],
    [ "GetMonthName", "class_weather_data.html#a8ad51a569e62121140f2adea65ea75ac", null ],
    [ "IsYearValid", "class_weather_data.html#a4b0abdd8172725328f015d79d9da8101", null ],
    [ "LoadData", "class_weather_data.html#a99deeb811e6288bd099ffc0e2cd33a93", null ],
    [ "PrintAverageTemperature", "class_weather_data.html#aa3ae4d5cbfe9c39fa0452c7232be3883", null ],
    [ "PrintAverageWindSpeed", "class_weather_data.html#ae6072b404d5ecad2c0340a883ba03adb", null ],
    [ "PrintSolarRadiation", "class_weather_data.html#a2cf2099298d415187accfd9ecd6e6a41", null ],
    [ "WriteDataToFile", "class_weather_data.html#a408938f063d58e7e00e2245744acc1e8", null ]
];