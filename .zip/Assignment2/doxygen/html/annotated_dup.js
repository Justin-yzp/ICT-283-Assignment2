var annotated_dup =
[
    [ "DataLoader", "class_data_loader.html", "class_data_loader" ],
    [ "DataProcessor", "class_data_processor.html", "class_data_processor" ],
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "MonthData", "struct_month_data.html", "struct_month_data" ],
    [ "WeatherData", "class_weather_data.html", "class_weather_data" ]
];