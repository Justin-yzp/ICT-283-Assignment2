var files_dup =
[
    [ "DataLoader.h", "_data_loader_8h_source.html", null ],
    [ "DataProcessor.h", "_data_processor_8h_source.html", null ],
    [ "Menu.h", "_menu_8h_source.html", null ],
    [ "WeatherData.h", "_weather_data_8h_source.html", null ]
];