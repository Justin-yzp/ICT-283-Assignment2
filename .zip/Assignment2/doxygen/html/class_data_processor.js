var class_data_processor =
[
    [ "DataProcessor", "class_data_processor.html#aa8b2355388d8179bd3ea1afef8280c0e", null ],
    [ "CalculateAverage", "class_data_processor.html#ad3f3ac3408414c66bebcdb450f17dd6c", null ],
    [ "CalculateStandardDeviation", "class_data_processor.html#af94987f5cff2fb68393795d1b595bad7", null ],
    [ "CalculateTotal", "class_data_processor.html#a1a688ff17ef013bf7b362c05697c8d51", null ],
    [ "DisplayDataForYear", "class_data_processor.html#a5c7ccaddd07a57a24e8380f3047528ba", null ],
    [ "GetData", "class_data_processor.html#acd2c4cb0e2fe8d51de77b810ce2435d4", null ],
    [ "GetMonthName", "class_data_processor.html#ad8c7b4be8c05766ec86548c90494dd72", null ],
    [ "PrintAverageTemperature", "class_data_processor.html#a0bfe24391d91f8fee183c8d2ae2d4157", null ],
    [ "PrintAverageWindSpeed", "class_data_processor.html#a2cad13e1757df0fd5b71e618401aa99a", null ],
    [ "PrintSolarRadiation", "class_data_processor.html#adb527fadb9e071eb8c15dc839ac3e5c8", null ],
    [ "Search", "class_data_processor.html#abe60eb8e7b6e2ac4e0bd9f6be9d1c3dc", null ],
    [ "WriteDataToFile", "class_data_processor.html#a9e18b3b2c48160dc242fceddcf4e4088", null ]
];