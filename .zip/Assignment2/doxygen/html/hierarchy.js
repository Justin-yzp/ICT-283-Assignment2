var hierarchy =
[
    [ "DataLoader", "class_data_loader.html", [
      [ "DataProcessor", "class_data_processor.html", null ]
    ] ],
    [ "Menu", "class_menu.html", null ],
    [ "MonthData", "struct_month_data.html", null ],
    [ "WeatherData", "class_weather_data.html", null ]
];