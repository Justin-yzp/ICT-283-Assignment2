var searchData=
[
  ['search_22',['Search',['../class_data_processor.html#abe60eb8e7b6e2ac4e0bd9f6be9d1c3dc',1,'DataProcessor']]]
];
