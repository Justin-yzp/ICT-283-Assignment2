var searchData=
[
  ['calculateaverage_30',['CalculateAverage',['../class_data_processor.html#ad3f3ac3408414c66bebcdb450f17dd6c',1,'DataProcessor::CalculateAverage()'],['../class_weather_data.html#a70c734e710bb8b9ab85234cfe473e640',1,'WeatherData::CalculateAverage(const std::vector&lt; double &gt; &amp;data)'],['../class_weather_data.html#abc6293d649af3eddfc231c359d0b26fe',1,'WeatherData::CalculateAverage(const std::vector&lt; MonthData &gt; &amp;values, double(MonthData::*data)() const)']]],
  ['calculatespcc_31',['CalculateSPCC',['../class_weather_data.html#a8ac06a32d094a84a563d01d779e074e0',1,'WeatherData']]],
  ['calculatestandarddeviation_32',['CalculateStandardDeviation',['../class_data_processor.html#af94987f5cff2fb68393795d1b595bad7',1,'DataProcessor::CalculateStandardDeviation()'],['../class_weather_data.html#a078589fe5dbbbdf691d79de21647b49f',1,'WeatherData::CalculateStandardDeviation()']]],
  ['calculatetotal_33',['CalculateTotal',['../class_data_processor.html#a1a688ff17ef013bf7b362c05697c8d51',1,'DataProcessor::CalculateTotal()'],['../class_weather_data.html#aa152e19ce16c31e7c60e23355f85d4aa',1,'WeatherData::CalculateTotal()']]]
];
