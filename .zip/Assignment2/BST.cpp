// bst.cpp

#include "bst.h"

// A helper function that inserts a new node into the binary search tree
template <typename T>
void BST<T>::insert(Node*& node, const T& data) {
    if (node == nullptr) { // If the node is empty, create a new node
        node = new Node(data);
    } else if (data < node->data) { // If the data is smaller than the node's data, insert into the left subtree
        insert(node->left, data);
    } else if (data > node->data) { // If the data is larger than the node's data, insert into the right subtree
        insert(node->right, data);
    } else { // If the data is equal to the node's data, do nothing
        return;
    }
}

// A helper function that prints the binary search tree in order
template <typename T>
void BST<T>::printInOrder(Node* node) const {
    if (node == nullptr) { // If the node is empty, return
        return;
    }
    printInOrder(node->left); // Print the left subtree
    std::cout << node->data << " "; // Print the node's data
    printInOrder(node->right); // Print the right subtree
}

// A helper function that deletes all nodes in the binary search tree
template <typename T>
void BST<T>::clear(Node*& node) {
    if (node == nullptr) { // If the node is empty, return
        return;
    }
    clear(node->left); // Delete the left subtree
    clear(node->right); // Delete the right subtree
    delete node; // Delete the node
    node = nullptr; // Set the node pointer to null
}

// Constructor
template <typename T>
BST<T>::BST() : root(nullptr) {}

// Destructor
template <typename T>
BST<T>::~BST() {
    clear(root); // Delete all nodes in the binary search tree
}

// A function that inserts a new data into the binary search tree
template <typename T>
void BST<T>::insert(const T& data) {
    insert(root, data); // Call the helper function with the root as the parameter
}

// A function that prints the binary search tree in order
template <typename T>
void BST<T>::printInOrder() const {
    printInOrder(root); // Call the helper function with the root as the parameter
    std::cout << std::endl;
}

// A function that returns the root of the binary search tree
template <typename T>
typename BST<T>::Node* BST<T>::getRoot() const {
    return root; // Return the root pointer
}
